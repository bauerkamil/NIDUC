# ARQ simulator
This is a project for NiDUC class
## Authors:
Kamil Bauer, <br />
Natalia Gornikowska, <br />
Kacper Kemblowski

# How to choose
Przy bicie parzystości ilość w pakiecie podzielna +1 przez długość wiad
Przy sumie ilość w pakiecie podzielna przez długość wiad
